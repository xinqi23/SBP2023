#!/bin/bash
mpirun -np 128 gmx_mpi mdrun -ntomp 1 -multidir 0 1 2 3 4 5 6 7 -s replica -c replica -e replica -x replica -g replica -plumed plumed.dat -cpi -cpo -append -v >& log.txt

exit 0
