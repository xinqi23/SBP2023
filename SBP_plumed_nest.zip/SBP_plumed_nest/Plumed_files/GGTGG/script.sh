#!/bin/bash

mpirun -np 32 gmx_mpi mdrun -ntomp 1 -multidir 0 1 2 3  -s replica  -c replica -e replica -x replica -g replica -plumed plumed.dat -cpi -cpo -cpt 1.0 -append -v >& log.txt 

exit 0
